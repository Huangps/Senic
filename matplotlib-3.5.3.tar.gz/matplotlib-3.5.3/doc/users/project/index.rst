.. redirect-from:: /users/backmatter

Project information
-------------------

.. toctree::
    :maxdepth: 2

    license.rst
    citing.rst
    credits.rst
    history.rst
