******************
``matplotlib.afm``
******************

.. automodule:: matplotlib.afm
   :members:
   :undoc-members:
   :show-inheritance:
